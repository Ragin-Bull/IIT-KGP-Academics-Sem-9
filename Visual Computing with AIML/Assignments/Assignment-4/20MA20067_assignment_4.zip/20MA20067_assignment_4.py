# %%
"""
<center>
<h1> Programming Assignment-4</h1>
<h3><b>Name:</b> Shatansh Patnaik</h3>
<h3><b>Roll No:</b> 20MA20067</h3>
<h3><b>Course</b>: Visual Computng with AI/ML<h3>
</center>

"""

# %%
"""
### Importing the essential libraries and frameworks
"""

# %%
import numpy as np
import cv2
import matplotlib.pyplot as plt

# %%
"""
## Task-1: Gaussian Bandpass Filtering in Frequency Domain
"""

# %%
_path = './a_3_inputs/a_3_task_1_input.png'
src_img = cv2.imread(_path, cv2.IMREAD_GRAYSCALE)

plt.imshow(src_img, cmap='gray')
plt.title("Original Image")
plt.show()

# %%
"""
### Custom implementations of DFT and IDFT:
"""

# %%
def perform_dft(img):
    M, N = img.shape
    m = np.arange(M).reshape((M, 1))
    n = np.arange(N).reshape((N, 1))

    k = np.arange(M).reshape((M, 1))
    l = np.arange(N).reshape((N, 1))

    converted_row = np.exp(-2j * np.pi * k @ m.T / M)
    converted_col = np.exp(-2j * np.pi * l @ n.T / N)

    dft_result = converted_row @ img @ converted_col

    real_part = np.real(dft_result)
    imaginary_part = np.imag(dft_result)
    
    return np.dstack((real_part, imaginary_part))

def perform_idft(complex_img):
    M, N, _ = complex_img.shape
    real_part = complex_img[:, :, 0]
    imaginary_part = complex_img[:, :, 1]
    
    img = real_part + 1j * imaginary_part
    
    idft_image = np.zeros((M, N), dtype=np.complex128)
    
    m = np.arange(M).reshape((M, 1))
    n = np.arange(N).reshape((N, 1))

    k = np.arange(M).reshape((M, 1))
    l = np.arange(N).reshape((N, 1))

    converted_row = np.exp(2j * np.pi * k @ m.T / M)
    converted_col = np.exp(2j * np.pi * l @ n.T / N)

    idft = converted_row @ img @ converted_col / (M * N)
    magnitude = np.abs(idft)
    
    return magnitude


def separate_magnitude_phase(img):
    real_part = img[:, : ,0]
    imaginary_part = img[:, : ,1]
    
    magnitude = np.sqrt(real_part**2 + imaginary_part**2)
    phase = np.arctan2(imaginary_part, real_part)
    
    return magnitude, phase

# %%
"""
### Getting and Applying the Gaussian Filter
"""

# %%
def get_gaussian_filters(shape, hi, lo, sigma_hi, sigma_lo):
    M, N = shape
    u = np.arange(M) - M // 2
    v = np.arange(N) - N // 2
    U, V = np.meshgrid(u, v, indexing='ij')
    D = np.sqrt(U**2 + V**2)
    
    gaussian_hi = 1 - np.exp(-(D**2) / (2 * (sigma_hi**2)))
    gaussian_lo = np.exp(-(D**2) / (2 * (sigma_lo**2)))

    return gaussian_hi, gaussian_lo

def apply_gaussian_bandpass_filter(img, hi, lo, sigma_hi, sigma_lo):
    dft = perform_dft(img)
    dft_shifted = np.fft.fftshift(dft)
    
    gaussian_hi, gaussian_lo = get_gaussian_filters(img.shape, hi, lo, sigma_hi, sigma_lo)
    gaussian_bandpass = gaussian_hi * gaussian_lo
    dft_filtered = dft_shifted * gaussian_bandpass[:, :, np.newaxis]

    dft_ishift = np.fft.ifftshift(dft_filtered)
    img_filtered = perform_idft(dft_ishift)
    
    return img_filtered, gaussian_bandpass

# %%
"""
### Plotting the DFT (magnitude and phase)
"""

# %%
magnitude, phase = separate_magnitude_phase(perform_dft(src_img))
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(np.log(magnitude + 1), cmap='gray')
plt.title('Magnitude (From Scratch)')

plt.subplot(1, 2, 2)
plt.imshow(phase, cmap='gray')
plt.title('Phase (From Scratch)')

plt.show()

# %%
"""
### Plotting the Gaussian Bandpass Filtered Image
"""

# %%
high_pass = 100.0
low_pass = 120.0 
sigma_hi = 64 
sigma_lo = 36

img_filtered, bandpass_filter = apply_gaussian_bandpass_filter(src_img, high_pass, low_pass, sigma_hi, sigma_lo)
plt.figure(figsize=(12, 6))

plt.subplot(1, 3, 1)
plt.imshow(src_img, cmap = 'gray')
plt.title('Original Image')

plt.subplot(1, 3, 2)
plt.imshow(bandpass_filter, cmap='gray')
plt.title('Gaussian Bandpass Filter')

plt.subplot(1, 3, 3)
plt.imshow(img_filtered, cmap='gray')
plt.title('Filtered Image')

plt.show()

# %%
"""
## Verification using OpenCV Functions
"""

# %%
def perform_dft_cv2(img):
    dft = cv2.dft(np.float32(img), flags=cv2.DFT_COMPLEX_OUTPUT)
    real_part, imaginary_part = cv2.split(dft)
    
    magnitude = cv2.magnitude(real_part, imaginary_part)
    phase = cv2.phase(real_part, imaginary_part)
    
    return magnitude, phase

def apply_gaussian_bandpass_filter_using_cv2(img, hi, lo, sigma_hi, sigma_lo):
    dft = cv2.dft(np.float32(img), flags=cv2.DFT_COMPLEX_OUTPUT)
    dft_shifted = np.fft.fftshift(dft)
    
    gaussian_hi, gaussian_lo = get_gaussian_filters(img.shape, hi, lo, sigma_hi, sigma_lo)
    gaussian_bandpass = gaussian_hi * gaussian_lo
    dft_filtered = dft_shifted * gaussian_bandpass[:, :, np.newaxis]

    dft_ishift = np.fft.ifftshift(dft_filtered)
    img_filtered = cv2.idft(dft_ishift)
    img_filtered = cv2.magnitude(img_filtered[:, :, 0], img_filtered[:, :, 1])
    
    return img_filtered, gaussian_bandpass

# %%
magnitude, phase = perform_dft_cv2(src_img)
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(np.log(magnitude + 1), cmap='gray')
plt.title('Magnitude (OpenCV)')

plt.subplot(1, 2, 2)
plt.imshow(phase, cmap='gray')
plt.title('Phase (OpenCV)')

plt.show()

# %%
img_filtered, bandpass_filter = apply_gaussian_bandpass_filter_using_cv2(src_img, high_pass, low_pass, sigma_hi, sigma_lo)
plt.figure(figsize=(12, 6))

plt.subplot(1, 3, 1)
plt.imshow(src_img, cmap = 'gray')
plt.title('Original Image')

plt.subplot(1, 3, 2)
plt.imshow(bandpass_filter, cmap='gray')
plt.title('Gaussian Bandpass Filter')

plt.subplot(1, 3, 3)
plt.imshow(img_filtered, cmap='gray')
plt.title('Filtered Image')

plt.show()

# %%
"""
## Task-2: Image Reconstruction
"""

# %%
def idft_from_magnitude_phase(image):
    M, N, _ = image.shape
    magnitude = image[:, :, 0]
    phase = image[:, :, 1]

    real_part = magnitude * np.cos(phase)
    imaginary_part = magnitude * np.sin(phase)

    spatial_image = perform_idft(np.dstack((real_part, imaginary_part)))
    
    return spatial_image

# %%
_path_1 = './a_3_inputs/a_3_task_2_im1.png'
_path_2 = './a_3_inputs/a_3_task_2_im2.png'

img_1 = cv2.imread(_path_1, cv2.IMREAD_GRAYSCALE)
img_2 = cv2.imread(_path_2, cv2.IMREAD_GRAYSCALE)

plt.subplot(1, 2, 1)
plt.imshow(img_1, cmap='gray')
plt.title('Image One')

plt.subplot(1, 2, 2)
plt.imshow(img_2, cmap='gray')
plt.title('Image Two')

plt.show()

# %%
dft_im1 = perform_dft(img_1)
dft_im2 = perform_dft(img_2)

mag_im1, phase_im_1 = separate_magnitude_phase(dft_im1)
mag_im2, phase_im_2 = separate_magnitude_phase(dft_im2)

# Constructing dft_im_ver1: Replacing the magnitude of dft_im1 by dft_im2
im_ver1 = idft_from_magnitude_phase(np.dstack((mag_im2, phase_im_1)))

# Constructing dft_im_ver1: Replacing the phase of dft_im1 by dft_im2
im_ver2 = idft_from_magnitude_phase(np.dstack((mag_im1, phase_im_2)))

# Constructing the original image
orginal_ver = idft_from_magnitude_phase(np.dstack((mag_im1, phase_im_1)))

# %%
plt.figure(figsize=(12, 6))

plt.subplot(1, 3, 1)
plt.imshow(orginal_ver, cmap='gray')
plt.title('Original Image')

plt.subplot(1, 3, 2)
plt.imshow(im_ver1, cmap='gray')
plt.title('Replacing the magnitude')

plt.subplot(1, 3, 3)
plt.imshow(im_ver2, cmap='gray')
plt.title('Replacing the phase')

plt.show()

# %%
"""
## Observations
"""

# %%
"""
We can observe that the image obtained from the replacement of the magnitude is the closest one, since if we replace the phase then the spatial arrangement of the different frequency components of the image changes. There phase is crucial for the reconstruction of the image.
"""

# %%
"""
## Task-3
"""

# %%
def compute_dft_magnitude(image):
    dft = cv2.dft(np.float32(image), flags=cv2.DFT_COMPLEX_OUTPUT)
    dft_shifted = np.fft.fftshift(dft)
    magnitude = cv2.magnitude(dft_shifted[:, :, 0], dft_shifted[:, :, 1])
    magnitude_spectrum = np.log(magnitude + 1)
    
    return magnitude_spectrum

def subsample_image(image):
    subsampled = image.copy()
    subsampled[::2, ::2] = 0
    return subsampled

# %%
_path = './a_3_inputs/a_3_task_3_input_a.png'
img = cv2.imread(_path, cv2.IMREAD_GRAYSCALE)

magnitude_spectrum_original = compute_dft_magnitude(img)
img_subsampled = subsample_image(img)
magnitude_spectrum_subsampled = compute_dft_magnitude(img_subsampled)

# %%
plt.figure(figsize=(12, 6))

plt.subplot(2, 2, 1)
plt.imshow(img, cmap='gray')
plt.title('Original Image')
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(magnitude_spectrum_original, cmap='gray')
plt.title('Magnitude Spectrum (Original)')
plt.axis('off')

plt.subplot(2, 2, 3)
plt.imshow(img_subsampled, cmap='gray')
plt.title('Subsampled Image')
plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(magnitude_spectrum_subsampled, cmap='gray')
plt.title('Magnitude Spectrum (Subsampled)')
plt.axis('off')

plt.show()

# %%
"""
## Observations
"""

# %%
"""
- After subsampling, the magnitude spectrum shows some significant differences. The frequency components appear to be more uniform, and the loss of detail manifests as a reduction in high-frequency information.

- The subsampled image causes the high-frequency components to be incorrectly represented in the magnitude spectrum. By zeroing out alternate pixels, we are effectively low-pass filtering the image. However, the DFT of this modified image introduces aliasing effects, which causes unexpected patterns or artifacts as seen in the magnitude spectrum of the subsampled image.

"""

# %%
def subsample_dft(dft):
    dft[::3, :, :] = 0
    return dft

# %%
_path = './a_3_inputs/a_3_task_3_input_b.png'
img = cv2.imread(_path, cv2.IMREAD_GRAYSCALE)

dft = cv2.dft(np.float32(img), flags=cv2.DFT_COMPLEX_OUTPUT)
dft_original = np.fft.fftshift(dft)

dft_subsampled = subsample_dft(dft_original.copy())

dft_ishift = np.fft.ifftshift(dft_subsampled)
idft = cv2.idft(dft_ishift)    
img_reconstructed = cv2.magnitude(idft[:, :, 0], idft[:, :, 1])

magnitude_spectrum_subsampled = cv2.magnitude(dft_subsampled[:, :, 0], dft_subsampled[:, :, 1])

# %%
plt.figure(figsize=(12, 6))

plt.subplot(1, 3, 1)
plt.imshow(img, cmap='gray')
plt.title('Original Image')
plt.axis('off')

plt.subplot(1, 3, 2)
plt.imshow(np.log(magnitude_spectrum_subsampled + 1), cmap='gray')
plt.title('Magnitude Spectrum')
plt.axis('off')

plt.subplot(1, 3, 3)
plt.imshow(img_reconstructed, cmap='gray')
plt.title('Reconstructed Image')
plt.axis('off')

plt.show()

# %%
"""
## Observations
"""

# %%
"""
- We observe that there is a loss of effect in the new reconstructed image. This is because the high-frequency components (which correspond to edges and fine details in the image) are not fully represented after subsampling. 

- Another one of the most important observation is that due to the removal of certain frequencies, the reconstructed image is showing up aliasing. This is seen in the form of the repetition of the same image 3 times, vertically. This is also as the high-frequency information is lost, then low-frequency components present in the image interfere and create false patterns that were not present in the original image.
"""